package com.ebc.vetexpress

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.ebc.vetexpress.data.AppDatabase
import com.ebc.vetexpress.data.repository.VeterinariaRoomRepository
import com.ebc.vetexpress.ui.screens.DogImageScreen
import com.ebc.vetexpress.ui.theme.VetExpressTheme
import com.ebc.vetexpress.viewmodel.VeterinariaViewModel
import com.ebc.vetexpress.viewmodel.VeterinariaViewModelFactory
import com.ebc.vetexpress.data.model.Veterinaria


class MainActivity : ComponentActivity() {
    private val database by lazy { AppDatabase.getDatabase(this) }
    private val repository by lazy { VeterinariaRoomRepository(database.veterinariaDao()) }
    private val viewModel: VeterinariaViewModel by viewModels {
        VeterinariaViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // AGREGAR VETERINARIA DE PRUEBA (solo una vez)
        viewModel.agregarVeterinaria(
            Veterinaria(
                nombre = "Vet Felina",
                direccion = "Av. Patitas 123",
                telefono = "4441234567",
                servicios = "Consulta, Vacunas"
            )
        )

        setContent {
            VetExpressTheme {
                DogImageScreen()
            }
        }
    }
}

