package com.ebc.vetexpress.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.ebc.vetexpress.data.model.Veterinaria
import kotlinx.coroutines.flow.Flow

@Dao
interface VeterinariaDao {
    @Query("SELECT * FROM veterinarias")
    fun obtenerTodas(): Flow<List<Veterinaria>>

    @Insert
    suspend fun insertar(veterinaria: Veterinaria)

    @Query("DELETE FROM veterinarias")
    suspend fun eliminarTodo()
}

