package com.vetexpress.app.data.repository

import com.vetexpress.app.data.VeterinariaDao
import com.vetexpress.app.data.model.Veterinaria
import kotlinx.coroutines.flow.Flow

class VeterinariaRoomRepository(private val dao: VeterinariaDao) {

    val todas: Flow<List<Veterinaria>> = dao.obtenerTodas()

    suspend fun insertar(vet: Veterinaria) {
        dao.insertar(vet)
    }

    suspend fun eliminarTodo() {
        dao.eliminarTodo()
    }
}

