package com.vetexpress.app.data.model

data class DogImage(
    val url: String
)