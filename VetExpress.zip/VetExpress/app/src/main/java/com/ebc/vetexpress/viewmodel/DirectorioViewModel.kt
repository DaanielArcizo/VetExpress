package com.vetexpress.app.viewmodel

import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import com.vetexpress.app.data.model.Veterinaria
import com.vetexpress.app.data.repository.VeterinariaRepository

class DirectorioViewModel : ViewModel() {

    private val repo = VeterinariaRepository()

    private val _veterinarias = mutableStateOf<List<Veterinaria>>(emptyList())
    val veterinarias: State<List<Veterinaria>> = _veterinarias

    init {
        cargarVeterinarias()
    }

    private fun cargarVeterinarias() {
        _veterinarias.value = repo.obtenerVeterinarias()
    }
}
