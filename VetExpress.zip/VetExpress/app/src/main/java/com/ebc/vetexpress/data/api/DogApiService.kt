package com.vetexpress.app.data.api

import com.vetexpress.app.data.model.DogImage
import retrofit2.http.GET

interface DogApiService {
    @GET("breeds/image/random")
    suspend fun getRandomDog(): DogImage
}
