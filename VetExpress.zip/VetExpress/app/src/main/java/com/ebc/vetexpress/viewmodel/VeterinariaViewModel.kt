package com.vetexpress.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vetexpress.app.data.model.Veterinaria
import com.vetexpress.app.data.repository.VeterinariaRoomRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VeterinariaViewModel(private val repository: VeterinariaRoomRepository) : ViewModel() {

    val veterinarias: StateFlow<List<Veterinaria>> = repository.todas
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun agregarVeterinaria(vet: Veterinaria) {
        viewModelScope.launch {
            repository.insertar(vet)
        }
    }

    fun borrarTodo() {
        viewModelScope.launch {
            repository.eliminarTodo()
        }
    }
}
